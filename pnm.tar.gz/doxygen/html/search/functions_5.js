var searchData=
[
  ['set_5fcolumns_36',['set_columns',['../pnm_8h.html#aa550e7de30a9f8fcb6b5a1fa2b17040c',1,'pnm.c']]],
  ['set_5fmagicnumber_37',['set_magicNumber',['../pnm_8h.html#a7c0fcbb53244631b0a793f3b4718bd37',1,'pnm.c']]],
  ['set_5fmatrix_38',['set_matrix',['../pnm_8h.html#ab53045a8fb9a0e162e179857cf392671',1,'pnm.c']]],
  ['set_5fmaxvaluepixel_39',['set_maxValuePixel',['../pnm_8h.html#a4939531f112add0633d5d9feb5dc44d8',1,'pnm.c']]],
  ['set_5frows_40',['set_rows',['../pnm_8h.html#a7408e95bed0f2d4104b27a7ba5d64142',1,'pnm.c']]]
];
