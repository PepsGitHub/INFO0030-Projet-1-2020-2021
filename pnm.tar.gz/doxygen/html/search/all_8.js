var searchData=
[
  ['write_5fmatrix_25',['write_matrix',['../pnm_8h.html#aab3a3cf34a6d5b49dfcd9e6a72b33e26',1,'pnm.c']]]
];
