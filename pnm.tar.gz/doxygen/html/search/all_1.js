var searchData=
[
  ['destroy_2',['destroy',['../pnm_8h.html#a58491419bac919cbdfabff82bc50cb96',1,'pnm.c']]]
];
