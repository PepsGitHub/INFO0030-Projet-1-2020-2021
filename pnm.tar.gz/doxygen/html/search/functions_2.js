var searchData=
[
  ['get_5fcolumns_27',['get_columns',['../pnm_8h.html#a23f9be656f9bcc4a4c0dda752cb5eec3',1,'pnm.c']]],
  ['get_5fmagicnumber_28',['get_magicNumber',['../pnm_8h.html#a2d40e244dbd127d675a5b8db00069feb',1,'pnm.c']]],
  ['get_5fmatrix_29',['get_matrix',['../pnm_8h.html#a8672587a600ad77f110fcc7ed7bf1bfe',1,'pnm.c']]],
  ['get_5fmaxvaluepixel_30',['get_maxValuePixel',['../pnm_8h.html#a1cb2d38b518c52783d84ec0c11836cad',1,'pnm.c']]],
  ['get_5frows_31',['get_rows',['../pnm_8h.html#a901df4d5aeceb60611faf395f91232d5',1,'pnm.c']]]
];
