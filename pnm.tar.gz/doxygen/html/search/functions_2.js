var searchData=
[
  ['get_5fcolumns_34',['get_columns',['../pnm_8h.html#a0f393416b483843d820d9925d70c7912',1,'pnm.c']]],
  ['get_5fmagicnumber_35',['get_magicNumber',['../pnm_8h.html#a70b22ccf901ed4ba64c9e57cdf76212c',1,'pnm.c']]],
  ['get_5fmatrix_36',['get_matrix',['../pnm_8h.html#a4ac780366f95935bcc87e97bebe9b79b',1,'pnm.c']]],
  ['get_5fmaxvaluepixel_37',['get_maxValuePixel',['../pnm_8h.html#aa76b1dfcc9ea351d19eb65ee082d8008',1,'pnm.c']]],
  ['get_5frows_38',['get_rows',['../pnm_8h.html#aeb958679d8f30f86ff9731399dd7a5d8',1,'pnm.c']]]
];
