var searchData=
[
  ['manage_5fcomments_10',['manage_comments',['../pnm_8h.html#a73824141663fc2775bfb9d9d6a481c3d',1,'pnm.c']]],
  ['manage_5fformat_5finput_11',['manage_format_input',['../pnm_8h.html#a365f11a35e9f401b19bc5b6c38970216',1,'pnm.c']]]
];
