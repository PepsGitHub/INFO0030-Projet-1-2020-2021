var searchData=
[
  ['verify_5foutput_24',['verify_output',['../pnm_8h.html#abd595448dd589ec1453651197c8dc0bb',1,'pnm.c']]]
];
