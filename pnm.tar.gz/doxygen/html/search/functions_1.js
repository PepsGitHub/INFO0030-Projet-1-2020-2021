var searchData=
[
  ['destroy_5fall_30',['destroy_all',['../pnm_8h.html#a4b295ed8d9864ca9680c02e0454d4441',1,'pnm.c']]],
  ['destroy_5fmatrix_5fcolumns_31',['destroy_matrix_columns',['../pnm_8h.html#ac5cd7654e3f3465bad7df75110681389',1,'pnm.c']]],
  ['destroy_5fmatrix_5frows_32',['destroy_matrix_rows',['../pnm_8h.html#a181e247c145dbccf642ab54446ef5c18',1,'pnm.c']]],
  ['destroy_5fpnm_33',['destroy_pnm',['../pnm_8h.html#a547b243309423699779d087dc39ce2eb',1,'pnm.c']]]
];
