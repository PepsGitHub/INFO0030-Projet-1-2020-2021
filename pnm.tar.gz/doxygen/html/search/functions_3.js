var searchData=
[
  ['load_5fmatrix_32',['load_matrix',['../pnm_8h.html#a8f6d192c26830c8ca12d3bff7bb7ac97',1,'pnm.c']]],
  ['load_5fpnm_33',['load_pnm',['../pnm_8h.html#adf533a1bc155f9ee83d90c5a1564468f',1,'pnm.c']]]
];
