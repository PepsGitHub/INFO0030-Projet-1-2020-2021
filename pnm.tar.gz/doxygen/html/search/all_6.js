var searchData=
[
  ['set_5fcolumns_18',['set_columns',['../pnm_8h.html#aa4241162b3abeaa872809e61efab1d0a',1,'pnm.c']]],
  ['set_5fmagicnumber_19',['set_magicNumber',['../pnm_8h.html#a047cce615f52a5bd7f8823d4cfaee7f1',1,'pnm.c']]],
  ['set_5fmatrix_20',['set_matrix',['../pnm_8h.html#a936ee2a95e6a8d44c2b954897afeae41',1,'pnm.c']]],
  ['set_5fmaxvaluepixel_21',['set_maxValuePixel',['../pnm_8h.html#a8efba952d2dd8b12a0a8825a11f3cf6b',1,'pnm.c']]],
  ['set_5frows_22',['set_rows',['../pnm_8h.html#a0a2fc05ea7f25509ff4586f45c82920c',1,'pnm.c']]],
  ['short_5foptions_23',['short_options',['../pnm_8h.html#a45eaca4f590a850aecb08f101a4d4712',1,'pnm.c']]]
];
