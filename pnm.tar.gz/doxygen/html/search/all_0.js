var searchData=
[
  ['create_5fmatrix_0',['create_matrix',['../pnm_8h.html#a9490e2b1f19a960db22fbb0499a642fb',1,'pnm.c']]],
  ['create_5fpnm_1',['create_pnm',['../pnm_8h.html#a91083f36dd80ee24e36ff6b4d9bc4977',1,'pnm.c']]]
];
