var searchData=
[
  ['create_5fmatrix_0',['create_matrix',['../pnm_8h.html#a38aa548069d6bb8934ec582a3dd6b979',1,'pnm.c']]],
  ['create_5fpnm_1',['create_pnm',['../pnm_8h.html#a91083f36dd80ee24e36ff6b4d9bc4977',1,'pnm.c']]]
];
